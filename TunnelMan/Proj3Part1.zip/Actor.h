#ifndef ACTOR_H_
#define ACTOR_H_

#include "GraphObject.h"
class StudentWorld;

//--------------------actor base class--------------------
class Actor: public GraphObject
{
private:
    StudentWorld* world;
    

public:
    //constructor
    Actor(StudentWorld* w, int imageID, int startX, int startY, Direction dir = right, double size = 1.0, unsigned int depth = 0)
    : GraphObject(imageID, startX, startY, dir, size, depth), world(w){
        setVisible(true);
    }
    
    //destructor
    virtual ~Actor() {};
    
    virtual void doSomething()=0;
    
    StudentWorld* getWorld() { return world; }
};

//--------------------tunnel man class--------------------
class TunnelMan : public Actor{
public:
    // Constructor
    TunnelMan(StudentWorld* world)
        : Actor(world, TID_PLAYER, 30, 60), xPos(30), yPos(60){}

    // Destructor
    virtual ~TunnelMan() {};
    
    void doSomething() override;

private:
    int xPos;
    int yPos;
    void moveByKey();

    
};

//--------------------earth class--------------------
class Earth : public Actor{
public:
    // Constructor
    Earth(StudentWorld* world, int startX, int startY)
        : Actor(world, TID_EARTH, startX, startY, right, 0.25, 3) {}

    // Destructor
    virtual ~Earth() {}

    virtual void doSomething() override {}
};


#endif // ACTOR_H_
