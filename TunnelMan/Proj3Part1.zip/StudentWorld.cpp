#include "StudentWorld.h"
#include "Actor.h"
#include <string>
using namespace std;

GameWorld* createStudentWorld(string assetDir)
{
	return new StudentWorld(assetDir);
}


//constructor
StudentWorld:: StudentWorld(string assetDir)
    : GameWorld(assetDir)
{
}

//--------------------init function--------------------
//initialize the data srtructures used to keep track of your games virtual world
//construct a new oil field
//allocate and insert a valid Tunnel man object and place it at the proper location
int StudentWorld:: init() {

    // Initialize Tunnelman
    tman = new TunnelMan(this);

    // Create Earth field
    for (int x = 0; x < VIEW_WIDTH; ++x) {
        for (int y = 0; y < 60; ++y) {
            if ((x >= 30 && x < 34) && (y >= 0 && y < 60)) {
                earthGrid[x][y] = new Earth(this, x, y);
                earthGrid[x][y]->setVisible(false);

            } else {
                earthGrid[x][y] = new Earth(this, x, y);
            }
        }
    }

    return GWSTATUS_CONTINUE_GAME;
    
}


//--------------------move function--------------------
//runs a single tick of the game
//asks each of the game's actors to do something
//disposes of actors that need to disappear
int StudentWorld:: move() {
    tman->doSomething();
    return GWSTATUS_CONTINUE_GAME;
}


//--------------------cleanup function--------------------
//when a player loses a life or completes a level
//frees all actors?
void StudentWorld:: cleanUp() {
    delete tman;
    for (int i = 0; i < 64; i++) {
        for (int j = 0; j < 60; j++) {

            delete earthGrid[i][j];

        }
    }
    actors.clear();
}


//remove earth function implementation
void StudentWorld:: removeEarth(int x, int y) {
    for (int i = x; i < x + 4; ++i) {
        for (int j = y; j < y + 4; ++j) {
            if ((i >= 0 && i < VIEW_WIDTH) && (j >= 0 && j < 60)) {
                earthGrid[i][j]->setVisible(false);
    
            }
        }
    }
}
