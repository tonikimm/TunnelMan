#ifndef STUDENTWORLD_H_
#define STUDENTWORLD_H_

#include "GameWorld.h"
#include "GameConstants.h"
#include <string>
#include <iostream>
#include <string>
#include <vector>
using namespace std;

class Actor;
class Earth;
class TunnelMan;

class StudentWorld : public GameWorld
{
public:
    StudentWorld(std::string assetDir);
    ~StudentWorld() { cleanUp(); }

    virtual int init();
    virtual int move();
    virtual void cleanUp();
    
    void setDisplayText();
    void removeEarth(int x, int y);

private:
    vector<Actor*> actors;
    TunnelMan* tman;
    Earth* earthGrid[VIEW_WIDTH][60];
};

#endif // STUDENTWORLD_H_
